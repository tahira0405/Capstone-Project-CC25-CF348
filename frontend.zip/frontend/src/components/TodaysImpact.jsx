export default function TodaysImpact() {
    return (
      <div className="bg-green-50 border border-green-200 p-4 rounded-md text-sm">
        <h4 className="font-semibold mb-2">Today's Impact</h4>
        <p>Recipes discovered: <strong>12</strong></p>
        <p>Ingredients identified: <strong>0</strong></p>
        <p>Calories estimated: <strong>2,840</strong></p>
        <p className="mt-2 text-green-600 text-xs">✅ Reducing food waste with AI</p>
      </div>
    );
  }
  