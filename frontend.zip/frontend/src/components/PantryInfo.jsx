export default function PantryInfo() {
    return (
      <div className="bg-white p-4 rounded-md border">
        <h4 className="font-semibold mb-2">Your Pantry</h4>
        <p className="text-sm text-gray-600">No ingredients added yet</p>
        <p className="text-xs text-gray-500 mt-1">Total ingredients: 0</p>
      </div>
    );
  }
  